package days02;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;

import org.doit.domain.EmpDeptSalgradeVO;
import org.doit.domain.EmpVO;

import com.util.DBConn;

/**
 * @author k2nik
 * @date 2024. 9. 3. 오후 12:09:46
 * @subject [jdbc] emp+dept+salgrade  => EmpDeptSalGradeVO
 * @content 
 */
public class Ex03 {

	public static void main(String[] args) {
		// Ex01_04.main() -> Ex03.main() 복사+붙이기.		
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		String sql =  "SELECT empno, ename, dname, hiredate , sal+NVL(comm,0) pay, grade "
				    + "FROM emp e JOIN dept d ON e.deptno = d.deptno "
				    + "           JOIN salgrade s ON e.sal BETWEEN s.losal AND s.hisal";
	   
		int empno;
		String ename;  
		LocalDateTime hiredate;
		double pay;
		String dname;
		int grade;
		
		ArrayList<EmpDeptSalgradeVO> list = new ArrayList<>();	
		EmpDeptSalgradeVO vo = null;
		
		try {			
			conn = DBConn.getConnection();
			stmt = conn.createStatement();			
			rs = stmt.executeQuery(sql);  
			
			while(rs.next()) {
				
				// empno, ename, dname, hiredate , sal+NVL(comm,0) pay, grade
				empno = rs.getInt("empno");
				ename = rs.getString("ename");
				dname = rs.getString("dname"); 
				hiredate = rs.getTimestamp("hiredate").toLocalDateTime();
				pay = rs.getDouble("pay");
				grade = rs.getInt("grade");
				
				vo = new EmpDeptSalgradeVO(empno, ename, hiredate, pay, dname, grade);				
				list.add(vo);				
				 	
			} // while
			
			list.forEach(evo->System.out.println(evo)); 
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			// 4. Connnection 객체 닫기 - close()
			try {
				rs.close();
				stmt.close();
				// conn.close();
				DBConn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
 

	} // main

} // class
