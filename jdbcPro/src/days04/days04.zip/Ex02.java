package days04;

public class Ex02 {

	public static void main(String[] args) {
		
		int totalRecord = 136;
		int currentPage = 1;
		int numberPerPage = 15;
		
		// BETWEEN start AND end;
		int totalPages = (int) Math.ceil( (double)totalRecord / numberPerPage );
		System.out.println("TOTAL PAGES : " + totalPages);
		
		int start, end;
		
		for (int i = 1; i <=  totalPages ; i++) {
			// 1    s 1 
			// 2    s 11
			// 3    s 21
			// 4    s 31
			// i    s (i-1)*numberPerPage+1   e s+numberPerPage-1
			start = (i-1)*numberPerPage+1;
			end = start+numberPerPage -1;
			if( end > totalRecord ) end = totalRecord;
			
			System.out.printf("%d 페이지 : start=%d~end=%d\n", i, start, end);
		}

	}

}









